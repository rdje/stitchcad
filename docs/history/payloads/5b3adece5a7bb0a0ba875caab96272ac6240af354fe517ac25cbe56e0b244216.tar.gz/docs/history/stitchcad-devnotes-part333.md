# Sealed archive — oldest complete maintenance journal group

Immutable historical segment, sealed by leaf `G1-SLICE.5d.1.2.2.h` on `2026-10-25` (UTC).

- **Sealed identity:** 142 lines, 11582 bytes, sha256:c9eef56dd6d17e38b22773b23a58873343d1d68e758913524a374e90303b4a48
- **Coverage:** whole committed source interval from f168eec4e43cc794dc3e989706215a61f44cdec4.
- Whole source interval: DEV_NOTES.md bytes 19199–30781, 11582 bytes, sha256:c9eef56dd6d17e38b22773b23a58873343d1d68e758913524a374e90303b4a48
- **Retrieval:** bytes below the first rule and blank line; exactly one terminal newline.
- **Write policy:** none; corrections belong in a later record.

---

## _(2026-10-25 UTC)_ — guard archive materialization and metadata evidence

0242 .a25.1 splits the three-producer archive group before implementation. The actual4027b36
materialization first mkdir is trapped with stores absent. The producing entry now resolves every
backing/source file, logical destination and implicit parent directory before activation. Each mkdir
and exclusive output open rechecks its authority. Valid caller stores survive; stores inside outputs
or archive backing refuse. Pure function bodies remain identical, and readonly list/read/verify ignore
unused stores without loading the profile or starting children. Independent AST adapters retain the
entire original CLI body/argv/formats and successful committed-comparison predicates.

D224 is a distinct fail-open metadata defect: any git-show failure took the first-transition exemption.
A controlled unavailable HEAD reproduces it in the actual predecessor body. The exemption now needs
an independent successful tree query proving master absence. Unavailable/present-unreadable/absent
controls pass with scoped readonly Git children and unchanged caller environment. Metadata checks
validate complete backing sources without inspecting or activating unused stores. No bounds, schemas,
source proof predicates or committed windows change.

Captures verify the whole materialized file population, prepared stores and fresh effect checks.
Fourteen physical refusals and eight compiled actual plan/activation/recheck/store/HEAD/Git faults
pass; device observations are simulated. Native public materialization/overwrite/retention/window11
proofs preserve exact source, backing and output bytes. Original archive suite passes28 and the
whole-window CLI suite682 controls/661 logical reads at its captured population. New retained records
are separately covered by the current native materialization and exact source/public-reader controls.

D223 is owned after .a25: two optional older ledger --continuity modes fail at packed294/296 and
also freeze whole task graphs. Their registered defaults do not call those modes. Whole committed
0241/0240 ledgers and archive-client/host-activation scope/proofs are retained214/310/311 before bounded
live growth, with live ownership and original source intervals intact. Promotion declined: existing
complete authority, pure APIs, independent evidence and immutable-retention rules cover this slice.

## _(2026-10-25 UTC)_ — retrieve diagnostic history through its public reader

0241 .f.archive-client closes D222 before the larger .a25 producer group. Original retained()
declared/read physical303/304/208 although archive rollover may retire those files. A private valid
packed fixture preserves every byte and removes those raw paths; the actual768aebe client refuses
its missing physical source before children. Current retained() reads all three logical identities
through the public archive CLI. Every child revalidates all physical backing files, profile/reader/
entry sources and local authority; prepared stores and unrelated caller values survive. No stores
or output are created by this read-only client. Git children exclude ambient repository/config
overrides. Original Git argv, byte slices, order, whole-record assertions, result fields and window11
source proof remain exact through an independent source comparison.

The seven physical controls caught an incomplete first plan: a required master replaced by an empty
directory disappeared from the file enumeration. Declaring the mandatory master explicitly fixes
that early refusal. Actual input/recheck/Git/read omissions and three provenance assertion omissions
produce seven independent assertion reds; three same-length content changes require their original
named refusals. Captured dispatch is separate from native packed-reader execution. Both Python3.9
and3.14 pass the real eight-child proof with fixture/source/archive bytes exact and no scratch residue.
The fixture also accepts records already packed by a later production window; current raw paths
are not dependencies of its reference oracle. No production window was changed or added.

Whole0239 ledger is retained213 before live growth, exactly from768aebe; all earlier archive bytes
stay unchanged. Final gate exposes task aggregate1500520B over its unchanged1500000B cap; whole
committed .a24 scope/proof is retained309 with ID/status/path ownership live and exact public source
interval proof. Book explains the continuity interface and limits. Promotion declined: existing
logical archive retrieval, complete plans and exact provenance rules already cover this repair.

## _(2026-10-25 UTC)_ — guard map and handoff fixture boundaries

0240 .a24: map now resolves generator/curated/task/decision inputs and all ten header/log outputs
before writes and Bash children; child Git context is checkout-bound and valid caller stores survive.
Handoff's ordinary49/17 mode stays readonly, including imported --real host arguments and invalid
unused stores. Explicit real mode prepares all sources/delegates/held-file output before children.
Actual captures/twenty physical refusals/nine compiled guard reds pass on Python3.9; sources exact.

D220 was a second map reference assumption: current-body extraction required one HTML comment
while the generator accepts five header forms. Independent five-shape and headerless metamorphic
controls now preserve the complete body. D221's stale D217 book blocker is corrected. The native
calibration passes10/two, but first baseline correctly blocks DiskWatch17532 FD39 at the repository
directory. Once released, actual clear0/held1/restored0 passes and holder exits0. No foreign app was
signalled, no checker weakened. D222 raw D217 retention dependency is owned by .a25 before window12.

Whole predecessor publication records/oldest ledger retained308/212 against bc730f4; node/path
ownership remains live. Removed unwatched copied defect totals from LIVE_STATUS; PLANNING owns
reports and D38 still owns their derived census. Promotion declined: existing plans/readonly rules.

## _(2026-10-25 UTC)_ — guard publication rendering and temporary authority

0239 .a23.3.2: original build forwarded ambient stores directly to mdBook; main also owned
temporary creation/deletion and two writes outside its copied-fixture guards. The builder now
closes current configuration/source inputs, inspects existing public output and tracked membership,
and renders into an exclusive planned target/scratch root. Generated files are enumerated before
public replacement; warning/status/input/chapter failures retain previous public bytes. mdBook
argv/cwd and docs/book/book stay unchanged. Source creation is disabled in the child configuration.

Incoming mdBook path/command overrides and unsupported config/theme/include inputs refuse. Git
context is bound to this checkout in child environments; parent Git/caller/store values survive.
Fixture roots resolve their copied population before creation and recheck complete teardown files.
Both direct main writes require mutable-file authority. Pure APIs retain their original AST.
The first-effect probe also caught missing main reader planning; complete status/roadmap/task/Rust
inputs are now validated, including the status-map read before it is opened.

Captured children verify authority without native fault execution; real mdBook retains original45
cases and malformed-generic repair. Mode-specific controls cover physical/source/output/device,
controlled index failures, exceptional cleanup and actual compiled guard omissions. A store fault
initially also removed Git context filtering; isolating it preserves independent assertion reasons.
The shape control caught an overstrict file/directory transition; complete owned-tree replacement
now accepts it. Directory snapshots catch empty-source additions; body OSErrors preserve their origin.
An overlapped renderer/source-copy attempt refused a moving input and is excluded; final controls
ran against stable rendered output. Python3.9 passes19 compiled guard reds,18 physical and two index
refusals; real native45/fixture40/ledger11+13/coverage9/glossary/producer census pass0.
Completed predecessor scopes and oldest activation ledger are exact8e497de intervals in307/211;
all node IDs/path owners remain live. Publication details now have a bounded book annex.
Promotion declined: established complete plans, closed child context and guarded fixture rules.

## _(2026-10-25 UTC)_ — retrieve publication history through its public reader

0238 .f.publication repairs D219: the fixture continuity check assumed raw archive files and
a closed task/catalog graph. Window11 retained the bytes while retiring physical records.
Logical reads now verify original Git intervals, immutable predecessor artifacts and ordered
predecessor nodes/windows; later additions are allowed. Missing/altered bytes, missing/reordered/
duplicate nodes/windows and catalog schema changes refuse. Ten independent controls and three
compiled guard omissions pass, alongside the original fixture/mutation/pure/AST contracts.
The first replay cache accidentally shared binary/text Git captures; mode-aware keys fix it.
Promotion declined: established public archive retrieval and exact predecessor preservation.
Whole predecessor journal/oldest ledger/native scopes are retained305/210/306 with Git intervals;
node IDs, paths and completed ownership remain live. Fixed collection and per-file caps stay unchanged.

## _(2026-10-25 UTC)_ — verify activated D217 package

0237 cleanup4.hunt: the director completed external native installation; status updated,
selected/running0.164.0, local package pinned. Read-only OS capture verifies daemon94696,
code-mode host97349 and their executable paths in local-c908efcffa6c95317b16105e7ef593d696493975524a5bcfa09e8a8b2e23959d-aarch64-apple-darwin.
Selected CLI SHA256 is3fe68efdbc14e99cbc614b2615514eaddf7520277696d7aee2eeead56dd2cd79;
all41 provenance file hashes match. Patch SHA256 isab991c79e05fb9d3da3fb6a78704d9d0a89a7b0e8863c6ea877c1c85c1bc22b9.
Original vendor CLI remains byte-exact d8990e3ee7acfbc26f91265b12a1a83f0fee40d0e0f8f1f40a37d4ec21f499cf.
No updater PID or automatic-update marker remains, consistent with native local selection.

The first daemon enumeration changed during observation; all observed metadata was readable.
That incomplete capture is retained as host-after-activation.json. The existing bounded native
snapshot control then obtains stable enumeration:51 readable daemon vnodes, zero host vnodes,
both native flavors complete, no ENOENT or untyped lsof marker. Complete proof is retained as
recovery-20261025/host-after-activation-complete.json below target/artifact_cleanup_audit/.
The strict handoff check initially refuses a separate DiskWatch scan:23927 and its du23930
child, launched outside this task, hold the repository. The director elected to let it finish.
Initial handoff/real-control refusals remain retained; neither foreign process was signalled.
After those processes exit, contract.py --real passes0:49 fixtures/17 assertion reds plus native
10 lifecycles/2 reds; real clear0/held-file1/restored0. Receipt: activation-handoff-real-final.log.
Historical FD10 identity stays unknown; D217 closes for the verified inheritance repair:
the reproduced inheritance class is prevented in the selected build. Full UI/model/voice
sessions and upstream adoption are unclaimed. Cleanup remains complete; stop before publication.
Whole0235 continuity ledger is retained209, independently checked against a65601d source bytes.
